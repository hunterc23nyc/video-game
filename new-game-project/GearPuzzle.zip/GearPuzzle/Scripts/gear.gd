class_name Gear
extends Area2D

@onready var sprite = $AnimatedSprite2D
var adjacent_spinning_gears: int = 0 # How many adjacent gears are spinning.
@export var driving: bool # If this gear is a driving gear (the one that starts the movement).
@export var unbreakable: bool
var spinning: bool = false # If this gear is spinning.
var rotation_speed: int = 2 # This gear's rotation speed. Should be the inverse of rotation speeds of adjacent gears.

func _process(delta: float) -> void:
	if (adjacent_spinning_gears > 0 || driving): spinning = true
	if (adjacent_spinning_gears == 0 && !driving): spinning = false
	if (spinning): 
		if (rotation_speed > 0): sprite.play("clockwise")
		else: sprite.play("counterclockwise")
		sprite.rotate(rotation_speed*delta)
	else: sprite.play("idle")

func refresh():
	if (!driving):
		adjacent_spinning_gears = 0
		for other_gear in get_overlapping_areas():
			if (other_gear.spinning):
				adjacent_spinning_gears += 1
				rotation_speed = -other_gear.rotation_speed
